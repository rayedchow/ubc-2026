# Mint Exchange

A Ledger district gym for Modélmon.

Open `exterior.glb` or `interior.glb` in Blender or a glTF 2.0 viewer. Both use meters, Y up, and +Z toward the entrance. Named meshes have local pivots at their bases. The landscaping nodes start with “Grounds” and can be hidden as a group. The unlit vertex colors carry the painted palette.

`exterior-angle.png` and `interior-angle.png` show the models in three-quarter view. `grounds.png` is the landscaped exterior. `building.png` is the standalone transparent building. `interior.png` is the empty training room, ready for the game's live leader and model sprites.

`map-atlas.png` contains the three availability states and six roof palettes. `props.png` contains six isolated furnishings in a 3 × 2 grid, in reading order. Use nearest-neighbor sampling. See `pack.json` for cell sizes, names, and placement anchors.
